"use strict";
/*global $ */
$(document).ready(function () { $("body").fadeIn(3000);
    $("#image").click(function () { $(".imageout").fadeOut(3000); });
    $("#imageChange").click(function () { $("#image").attr("src", "http://img.mobypicture.com/ac9221b42e4852370dde2768686b999e_large.jpg"); });
                              });