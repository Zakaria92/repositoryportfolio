"use strict";
/*global $ */
        $(document).ready(function () {

                $("#groot").click(function () {
                        var groot = parseFloat($("p").css("font-size"));
                        $("p").css("font-size",(1.2 * groot) + "px");
                });
            });