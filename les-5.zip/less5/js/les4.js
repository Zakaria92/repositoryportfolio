"use strict";
/*global $ */
$(document).ready(function () {
  
    
    
    
    
    
    var plaats = $("li").last().detach();
    var aantal = $("li").length;
    var lijn = $("li:nth-child(3n)").text();
  

    $($("li").first()).before("Aantal plaatsen: " + aantal);
    $($("li").first()).before(plaats);
    $($("li").last()).after("Weer 3 : " + lijn);

    
    $(document).ready(function() {
    	$('#input').click(function() {
					$('#steden').append($('<li>', {
						text : $('#inputStad').val()
					}));
				});
			})

			$(document).ready(function() {
				$("ul li").click(function() {
					$("ul li").css({
						"font-size" : "200%",
						"font-weight" : "bolder"
					})
				})
			})

			
			$(document).ready(function() {
				$("ul li").click(function(event) {
					if (event.target == this) {
						$("ul li").css.toggleClass("Normaal");
					}

				});
			});
    
    
    
    
});

	